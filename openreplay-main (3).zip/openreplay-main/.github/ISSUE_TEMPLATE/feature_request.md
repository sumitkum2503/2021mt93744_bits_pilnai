---
name: Feature request
about: Suggest an idea or a feature to improve OpenReplay
title: ''
labels: feature-request
assignees: estradino

---

Briefly describe the feature you would like to see shipped with the upcoming versions of OpenReplay, the use-case (very important to us) and the alternative solutions you've considered so far.
