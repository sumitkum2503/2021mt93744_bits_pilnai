The OpenReplay Enterprise license (the “Enterprise License”)
Copyright (c) 2022 Asayer, Inc.

To license the Enterprise Edition of OpenReplay, and take advantage of its additional features, functionality and support, you must agree to the terms of the OpenReplay Enterprise License Agreement. Please contact OpenReplay at [sales@openreplay.com](mailto:sales@openreplay.com).
