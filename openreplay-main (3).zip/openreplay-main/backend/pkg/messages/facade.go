package messages

func Encode(msg Message) []byte {
	return msg.Encode()
}
