def int_arg(x):
    return int(x) if x is not None else int(0)


def float_arg(x):
    return float(x) if x is not None else float(0)


def string(x):
    return x
