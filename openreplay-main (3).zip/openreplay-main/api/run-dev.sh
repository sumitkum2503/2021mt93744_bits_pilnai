#!/bin/zsh

uvicorn app:app --reload